from flask import Flask, jsonify, request

app = Flask(__name__)

clients = []

@app.route('/api/clients', methods=['GET'])
def get_clients():
    return jsonify(clients)

@app.route('/api/clients', methods=['POST'])
def add_client():
    data = request.json
    new_client = {
        'id': len(clients) + 1,
        'name': data['name'],
        'allowedIp': data['allowedIp']
    }
    clients.append(new_client)
    return jsonify(new_client), 201

@app.route('/api/clients/<int:client_id>', methods=['DELETE'])
def delete_client(client_id):
    global clients
    clients = [client for client in clients if client['id'] != client_id]
    return '', 204

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
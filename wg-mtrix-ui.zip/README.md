# WG-MTRIX UI

This project provides a user interface for managing WireGuard clients.

## Installation

1. Clone the repository:
   ```bash
   git clone <your-repository-url>
   cd wg-mtrix-ui
   ```

2. Build the Docker image:
   ```bash
   docker build -t wg-mtrix-ui .
   ```

3. Run the container:
   ```bash
   docker run -d -p 5000:5000 --name wg-mtrix-ui wg-mtrix-ui
   ```

4. Access the application in your browser at `http://<your-server-ip>:5000`.

## Updating

To update the repository on GitHub:

1. Add, commit, and push changes:
   ```bash
   git add .
   git commit -m "Update UI"
   git push
   ```

2. Rebuild and restart the Docker container:
   ```bash
   docker build -t wg-mtrix-ui .
   docker stop wg-mtrix-ui
   docker rm wg-mtrix-ui
   docker run -d -p 5000:5000 --name wg-mtrix-ui wg-mtrix-ui
   ```